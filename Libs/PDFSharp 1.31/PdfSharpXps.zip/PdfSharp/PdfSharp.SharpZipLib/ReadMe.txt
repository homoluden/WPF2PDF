
This code is an excerpt from the SharpZipLib. The code is unmodified except that all classes
are made internal and moved to the namespace PdfSharp.SharpZipLib.
