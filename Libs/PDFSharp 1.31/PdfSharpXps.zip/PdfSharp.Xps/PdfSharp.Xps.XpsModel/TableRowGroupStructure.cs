﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PdfSharp.Xps.XpsModel
{
  /// <summary>
  /// Contains the set of table rows that make up a table.
  /// </summary>
  class TableRowGroupStructure : XpsElement
  {
  }
}