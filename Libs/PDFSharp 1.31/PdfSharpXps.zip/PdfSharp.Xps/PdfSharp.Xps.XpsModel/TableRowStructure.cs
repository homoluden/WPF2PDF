﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PdfSharp.Xps.XpsModel
{
  /// <summary>
  /// Contains the set of table cells that make up a row of a table.
  /// </summary>
  class TableRowStructure : XpsElement
  {
  }
}