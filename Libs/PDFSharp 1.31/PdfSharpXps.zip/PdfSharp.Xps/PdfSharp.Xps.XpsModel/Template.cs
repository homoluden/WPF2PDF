﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PdfSharp.Xps.XpsModel
{
  /// <summary>
  /// 
  /// </summary>
  class Template : XpsElement
  {
    /// <summary>
    /// 
    /// </summary>
    public string Temp { get; set; }
  }
}