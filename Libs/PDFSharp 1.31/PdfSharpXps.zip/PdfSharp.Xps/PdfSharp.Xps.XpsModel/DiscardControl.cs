﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PdfSharp.Xps.XpsModel
{
  /// <summary>
  /// Contains a list of resources that are safe for a consumer to discard.
  /// </summary>
  class DiscardControl : XpsElement
  {
  }
}