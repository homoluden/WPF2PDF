﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PdfSharp.Xps.XpsModel
{
  /// <summary>
  /// Contains a collection of items that are group together in a list.
  /// </summary>
  class ListStructure : XpsElement
  {
  }
}