﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PdfSharp.Xps.XpsModel
{
  /// <summary>
  /// Represents a collection of PathSegment objecs.
  /// </summary>
  class PathSegmentCollection : List<PathSegment>
  {
    // Currently just a placeholder of a generic list.
  }
}