﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PdfSharp.Xps.XpsModel
{
  /// <summary>
  /// Represents a collection of PathFigure objecs.
  /// </summary>
  class PathFigureCollection : List<PathFigure>
  {
    // Currently just a placeholder of a generic list.
  }
}