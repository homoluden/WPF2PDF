﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PdfSharp.Xps.XpsModel
{
  /// <summary>
  /// Contains a complete definition of a table in the XPS Document.
  /// </summary>
  class TableStructure : XpsElement
  {
  }
}