﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PdfSharp.Xps.XpsModel
{
  /// <summary>
  /// Groups the named elements that constitute a single drawing or diagram.
  /// </summary>
  class FigureStructure : XpsElement
  {
  }
}