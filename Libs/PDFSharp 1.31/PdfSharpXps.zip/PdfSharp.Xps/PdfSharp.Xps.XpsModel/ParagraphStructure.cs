﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PdfSharp.Xps.XpsModel
{
  /// <summary>
  /// Contains the named elements that constitute a single paragraph.
  /// </summary>
  class ParagraphStructure : XpsElement
  {
  }
}