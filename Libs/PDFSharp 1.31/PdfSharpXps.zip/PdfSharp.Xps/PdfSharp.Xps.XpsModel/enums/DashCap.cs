﻿using System;

namespace PdfSharp.Xps.XpsModel
{
  enum DashCap
  {
    Flat,
    Round,
    Square,
    Triangle,
  }
}