﻿using System;

namespace PdfSharp.Xps.XpsModel
{
  enum EdgeMode
  {
    Aliased,
  }
}