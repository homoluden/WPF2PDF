﻿using System;

namespace PdfSharp.Xps.XpsModel
{
  enum ClrIntMode
  {
    ScRgbLinearInterpolation,
    SRgbLinearInterpolation,
  }
}