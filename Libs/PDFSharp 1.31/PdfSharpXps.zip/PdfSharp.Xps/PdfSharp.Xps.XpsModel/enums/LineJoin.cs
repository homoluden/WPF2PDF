﻿using System;

namespace PdfSharp.Xps.XpsModel
{
  enum LineJoin
  {
    Miter,
    Bevel,
    Round,
  }
}