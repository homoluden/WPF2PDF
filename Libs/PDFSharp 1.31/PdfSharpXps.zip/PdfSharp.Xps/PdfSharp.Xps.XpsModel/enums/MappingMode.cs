﻿using System;

namespace PdfSharp.Xps.XpsModel
{
  enum MappingMode
  {
    Absolute,
  }
}