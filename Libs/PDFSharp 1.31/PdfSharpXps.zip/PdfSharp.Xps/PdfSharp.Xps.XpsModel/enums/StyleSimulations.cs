﻿using System;

namespace PdfSharp.Xps.XpsModel
{
  enum StyleSimulations
  {
    None,
    ItalicSimulation,
    BoldSimulation,
    BoldItalicSimulation,
  }
}