﻿using System;

namespace PdfSharp.Xps.XpsModel
{
  enum LineCap
  {
    Flat,
    Round,
    Square,
    Triangle,
  }
}