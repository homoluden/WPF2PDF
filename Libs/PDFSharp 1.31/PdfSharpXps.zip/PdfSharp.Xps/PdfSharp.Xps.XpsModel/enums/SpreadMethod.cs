﻿using System;

namespace PdfSharp.Xps.XpsModel
{
  enum SpreadMethod
  {
    Pad,
    Reflect,
    Repeat,
  }
}