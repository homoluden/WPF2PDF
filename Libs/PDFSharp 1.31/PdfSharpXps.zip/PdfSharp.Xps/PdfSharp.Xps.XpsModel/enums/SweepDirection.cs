﻿using System;

namespace PdfSharp.Xps.XpsModel
{
  enum SweepDirection // save values as System.Windows.Media.SweepDirection
  {
    Counterclockwise,
    Clockwise,
  }
}