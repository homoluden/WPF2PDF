﻿using System;

namespace PdfSharp.Xps.XpsModel
{
  enum FillRule
  {
    EvenOdd,
    NonZero,
  }
}