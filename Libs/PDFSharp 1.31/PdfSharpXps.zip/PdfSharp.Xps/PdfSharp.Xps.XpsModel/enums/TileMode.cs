﻿using System;

namespace PdfSharp.Xps.XpsModel
{
  enum TileMode
  {
    None,
    Tile,
    FlipX,
    FlipY,
    FlipXY,
  }
}