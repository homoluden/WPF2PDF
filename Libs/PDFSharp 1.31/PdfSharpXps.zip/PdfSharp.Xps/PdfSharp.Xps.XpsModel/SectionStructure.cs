﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PdfSharp.Xps.XpsModel
{
  /// <summary>
  /// Provides an arbitrary grouping of content structural markup elements.
  /// </summary>
  class SectionStructure : XpsElement
  {
  }
}