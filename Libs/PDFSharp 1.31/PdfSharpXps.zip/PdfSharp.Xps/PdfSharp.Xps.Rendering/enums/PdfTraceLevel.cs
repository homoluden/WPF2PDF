﻿using System;

namespace PdfSharp.Xps.Rendering
{
  enum PdfTraceLevel
  {
    None,

    Verbose,
 }
}