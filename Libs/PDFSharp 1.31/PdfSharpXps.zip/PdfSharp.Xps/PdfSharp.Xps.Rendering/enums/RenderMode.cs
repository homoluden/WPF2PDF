﻿using System;

namespace PdfSharp.Xps.Rendering
{
  enum RenderMode
  {
    Default,

    SoftMask,
 }
}